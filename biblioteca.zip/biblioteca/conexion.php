<?php
class conexion{
    public function conectar(){
        $s="localhost";
        $dsn="mysql:host=$s;dbname=biblioteca";
        $u="root";
        $p="";

        try{
            $conn=new PDO($dsn,$u,$p);
        }catch(Exception $e){
            header('Content-Type: application/json');
            die(json_encode(array("error" => "Conexion fallida: " . $e->getMessage())));
        }
        return $conn;
    }

}
?>