<?php
include "conexion.php";

class Crud{
    public static function listarAutores(){
        $conn=new conexion();
        $conectar=$conn->conectar();
        $sql="select * from autores";
        $res=$conectar->prepare($sql);
        $res->execute();

        echo json_encode($res->fetchAll(PDO::FETCH_ASSOC));
    }

    public static function BuscarAutor(){
        $conn=new conexion();
        $conectar=$conn->conectar();
        $cedula=$_GET['cedula'];
        $sql="select * from autores where cedula='$cedula'";
        $res=$conectar->prepare($sql);
        $res->execute();

        echo json_encode($res->fetchAll(PDO::FETCH_ASSOC));
    }

    public static function InsertarAutor(){
        $conn=new conexion();
        $conectar=$conn->conectar();
        $cedula=$_POST['cedula'];
        $nombre=$_POST['nombre'];
        $apellido=$_POST['apellido'];
        $sql="insert into autores (cedula,nombre,apellido) values('$cedula','$nombre','$apellido')";
        $res=$conectar->prepare($sql);
        $res->execute();

        echo json_encode("autor insertado");
    }
    public static function EditarAutor(){
        $conn=new conexion();
        $conectar=$conn->conectar();
        parse_str(file_get_contents("php://input"),$datos);
        $cedula=$datos['cedula'];
        $nombre=$datos['nombre'];
        $apellido=$datos['apellido'];
        $sql="update autores set nombre='$nombre', apellido='$apellido' where cedula ='$cedula'";
        $res=$conectar->prepare($sql);
        $res->execute();

        echo json_encode("autor editado");

    }

    public static function EliminarAutor(){
        $conn=new conexion();
        $conectar=$conn->conectar();
        $cedula=$_GET['cedula'];
        $sql="delete from autores where cedula='$cedula'";
        $res=$conectar->prepare($sql);
        $res->execute();

        echo json_encode("autor eliminado");

    }
}

$metodo = $_SERVER['REQUEST_METHOD'];
$tabla=isset($_GET['tabla']) ? $_GET['tabla'] : 'autores';
if ($tabla=='autores'){
    if($metodo=='GET'){
        if(isset($_GET['cedula'])){
            crud::BuscarAutor();
        }else{
            crud::listarAutores();
        }
    }
    elseif($metodo=='POST'){
        crud::InsertarAutor();
    }elseif($metodo=='PUT'){
        crud::EditarAutor();
    }elseif($metodo=='DELETE'){
        crud::EliminarAutor();
    }
}
?>