// URL base del API
const API_URL = 'crud.php';

// Elementos del DOM
const formAutor = document.getElementById('formAutor');
const cedula = document.getElementById('cedula');
const nombre = document.getElementById('nombre');
const apellido = document.getElementById('apellido');
const btnGuardar = document.getElementById('btnGuardar');
const btnLimpiar = document.getElementById('btnLimpiar');
const btnBuscar = document.getElementById('btnBuscar');
const btnMostrarTodos = document.getElementById('btnMostrarTodos');
const searchCedula = document.getElementById('searchCedula');
const tbodyAutores = document.getElementById('tbodyAutores');
const alerta = document.getElementById('alerta');

let isEditando = false;

// Inicialización
document.addEventListener('DOMContentLoaded', function() {
    cargarAutores();
    agregarEventListeners();
});

// Agregar event listeners
function agregarEventListeners() {
    formAutor.addEventListener('submit', manejarGuardar);
    btnBuscar.addEventListener('click', buscarAutor);
    btnMostrarTodos.addEventListener('click', cargarAutores);
    searchCedula.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            buscarAutor();
        }
    });
}

// Cargar todos los autores
async function cargarAutores() {
    try {
        const response = await fetch(`${API_URL}?tabla=autores`, {
            method: 'GET'
        });

        const data = await response.json();
        
        // Validar que la respuesta sea un array
        if (Array.isArray(data)) {
            mostrarAutores(data);
            searchCedula.value = '';
        } else if (data.error) {
            mostrarAlerta(data.error, 'error');
            mostrarAutores([]);
        } else {
            mostrarAlerta('Error: respuesta inválida del servidor', 'error');
            mostrarAutores([]);
        }
    } catch (error) {
        console.error('Error al cargar autores:', error);
        mostrarAlerta('Error al cargar autores: ' + error.message, 'error');
        mostrarAutores([]);
    }
}

// Mostrar autores en la tabla
function mostrarAutores(autores) {
    tbodyAutores.innerHTML = '';

    // Validar que sea un array
    if (!Array.isArray(autores) || autores.length === 0) {
        tbodyAutores.innerHTML = '<tr><td colspan="4" class="text-center">No hay autores registrados</td></tr>';
        return;
    }

    autores.forEach(autor => {
        const fila = document.createElement('tr');
        fila.innerHTML = `
            <td>${autor.cedula}</td>
            <td>${autor.nombre}</td>
            <td>${autor.apellido}</td>
            <td>
                <div class="table-actions">
                    <button class="btn btn-warning btn-small" onclick="editarAutor('${autor.cedula}', '${autor.nombre}', '${autor.apellido}')">Editar</button>
                    <button class="btn btn-danger btn-small" onclick="eliminarAutor('${autor.cedula}')">Eliminar</button>
                </div>
            </td>
        `;
        tbodyAutores.appendChild(fila);
    });
}

// Buscar autor por cédula
async function buscarAutor() {
    const valorBusqueda = searchCedula.value.trim();

    if (!valorBusqueda) {
        mostrarAlerta('Por favor ingresa una cédula', 'warning');
        return;
    }

    try {
        const response = await fetch(`${API_URL}?tabla=autores&cedula=${encodeURIComponent(valorBusqueda)}`, {
            method: 'GET'
        });

        const data = await response.json();
        
        if (Array.isArray(data)) {
            mostrarAutores(data);
            if (data.length === 0) {
                mostrarAlerta('No se encontró autor con esa cédula', 'info');
            }
        } else if (data.error) {
            mostrarAlerta(data.error, 'error');
            mostrarAutores([]);
        }
    } catch (error) {
        console.error('Error al buscar autor:', error);
        mostrarAlerta('Error al buscar autor: ' + error.message, 'error');
    }
}

// Manejar guardar (insertar o actualizar)
async function manejarGuardar(e) {
    e.preventDefault();

    const cedulaValue = cedula.value.trim();
    const nombreValue = nombre.value.trim();
    const apellidoValue = apellido.value.trim();

    if (!cedulaValue || !nombreValue || !apellidoValue) {
        mostrarAlerta('Todos los campos son requeridos', 'warning');
        return;
    }

    if (isEditando) {
        await actualizarAutor(cedulaValue, nombreValue, apellidoValue);
    } else {
        await insertarAutor(cedulaValue, nombreValue, apellidoValue);
    }
}

// Insertar nuevo autor
async function insertarAutor(ced, nom, ape) {
    try {
        const formData = new FormData();
        formData.append('cedula', ced);
        formData.append('nombre', nom);
        formData.append('apellido', ape);

        const response = await fetch(`${API_URL}?tabla=autores`, {
            method: 'POST',
            body: formData
        });

        const data = await response.json();
        mostrarAlerta('Autor insertado exitosamente', 'success');
        formAutor.reset();
        cargarAutores();
    } catch (error) {
        console.error('Error al insertar:', error);
        mostrarAlerta('Error al insertar autor', 'error');
    }
}

// Editar autor (cargar datos en el formulario)
function editarAutor(ced, nom, ape) {
    cedula.value = ced;
    nombre.value = nom;
    apellido.value = ape;
    isEditando = true;
    btnGuardar.textContent = 'Actualizar';
    btnGuardar.style.background = 'var(--warning-color)';
    cedula.disabled = true;
    cedula.style.opacity = '0.7';
    cedula.style.cursor = 'not-allowed';
    cedula.focus();
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Actualizar autor
async function actualizarAutor(ced, nom, ape) {
    try {
        const params = new URLSearchParams();
        params.append('cedula', ced);
        params.append('nombre', nom);
        params.append('apellido', ape);

        const response = await fetch(`${API_URL}?tabla=autores`, {
            method: 'PUT',
            body: params
        });

        const data = await response.json();
        mostrarAlerta('Autor actualizado exitosamente', 'success');
        cancelarEdicion();
        cargarAutores();
    } catch (error) {
        console.error('Error al actualizar:', error);
        mostrarAlerta('Error al actualizar autor', 'error');
    }
}

// Cancelar edición
function cancelarEdicion() {
    isEditando = false;
    formAutor.reset();
    btnGuardar.textContent = 'Guardar';
    btnGuardar.style.background = 'var(--primary-color)';
    cedula.disabled = false;
    cedula.style.opacity = '1';
    cedula.style.cursor = 'pointer';
}

// Eliminar autor
async function eliminarAutor(ced) {
    if (!confirm('¿Estás seguro de que deseas eliminar este autor?')) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}?tabla=autores&cedula=${encodeURIComponent(ced)}`, {
            method: 'DELETE'
        });

        const data = await response.json();
        mostrarAlerta('Autor eliminado exitosamente', 'success');
        cargarAutores();

        // Si estaba en edición, cancelar
        if (isEditando && cedula.value === ced) {
            cancelarEdicion();
        }
    } catch (error) {
        console.error('Error al eliminar:', error);
        mostrarAlerta('Error al eliminar autor', 'error');
    }
}

// Mostrar alertas
function mostrarAlerta(mensaje, tipo = 'info') {
    alerta.textContent = mensaje;
    alerta.className = `alerta ${tipo} show`;

    setTimeout(() => {
        alerta.classList.remove('show');
    }, 3500);
}

// Validación en tiempo real
cedula.addEventListener('input', function() {
    this.value = this.value.replace(/[^0-9]/g, '');
});

nombre.addEventListener('input', function() {
    this.value = this.value.replace(/[^a-záéíóúñA-ZÁÉÍÓÚÑ\s]/g, '');
});

apellido.addEventListener('input', function() {
    this.value = this.value.replace(/[^a-záéíóúñA-ZÁÉÍÓÚÑ\s]/g, '');
});
