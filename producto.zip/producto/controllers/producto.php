<?php
include "../models/conexion.php";
include "../models/Producto.php";

$producto = new Producto();

$accion = $_GET['accion'] ?? 'listar';
$busqueda = false;
$resultado_busqueda = null;

// Procesar búsqueda
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['buscar_id'])) {
    $id = $_POST['buscar_id'];
    $exe = $producto->obtenerPorId($conn, $id);
    
    if($exe->num_rows > 0) {
        $resultado_busqueda = mysqli_fetch_assoc($exe);
        $busqueda = true;
    }
}

// Limpiar búsqueda
if(isset($_GET['limpiar'])) {
    $busqueda = false;
    $resultado_busqueda = null;
}

// Insertar
if($accion == 'insertar' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $stock = $_POST['stock'];
    
    if($producto->insertar($conn, $id, $nombre, $stock)) {
        header("Location: producto.php");
        exit();
    }
}

// Actualizar
if($accion == 'actualizar' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $stock = $_POST['stock'];
    
    if($producto->actualizar($conn, $id, $nombre, $stock)) {
        header("Location: producto.php");
        exit();
    }
}

// Eliminar
if($accion == 'eliminar') {
    $id = $_GET['id'];
    $producto->eliminar($conn, $id);
    header("Location: producto.php");
    exit();
}

// Obtener todos los productos
$res = $producto->obtenerTodos($conn);
$productos = array();
if($res->num_rows > 0) {
    while($row = $res->fetch_assoc()) {
        $productos[] = $row;
    }
}

include "../views/producto.php";
?>
