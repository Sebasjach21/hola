<?php
include "../models/conexion.php";
include "../models/Cliente.php";

$cliente = new Cliente();

$accion = $_GET['accion'] ?? 'listar';
$busqueda = false;
$resultado_busqueda = null;

// Procesar búsqueda
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['buscar_cedula'])) {
    $ced = $_POST['buscar_cedula'];
    $exe = $cliente->obtenerPorCedula($conn, $ced);
    
    if($exe->num_rows > 0) {
        $resultado_busqueda = mysqli_fetch_assoc($exe);
        $busqueda = true;
    }
}

// Limpiar búsqueda
if(isset($_GET['limpiar'])) {
    $busqueda = false;
    $resultado_busqueda = null;
}

// Insertar
if($accion == 'insertar' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $cedula = $_POST['cedula'];
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    
    if($cliente->insertar($conn, $cedula, $nombre, $apellido)) {
        header("Location: cliente.php");
        exit();
    }
}

// Actualizar
if($accion == 'actualizar' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $cedula = $_POST['cedula'];
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    
    if($cliente->actualizar($conn, $cedula, $nombre, $apellido)) {
        header("Location: cliente.php");
        exit();
    }
}

// Eliminar
if($accion == 'eliminar') {
    $cedula = $_GET['cedula'];
    $cliente->eliminar($conn, $cedula);
    header("Location: cliente.php");
    exit();
}

// Obtener todos los clientes
$res = $cliente->obtenerTodos($conn);
$clientes = array();
if($res->num_rows > 0) {
    while($row = $res->fetch_assoc()) {
        $clientes[] = $row;
    }
}

include "../views/cliente.php";
?>
