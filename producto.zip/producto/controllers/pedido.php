<?php
include "../models/conexion.php";
include "../models/pedido.php";
include "../models/Cliente.php";
include "../models/Producto.php";

$pedido = new Pedidos();
$cliente = new Cliente();
$producto = new Producto();

$accion = $_GET['accion'] ?? 'listar';
$busqueda = false;
$resultado_busqueda = null;
$error = null;
$mensaje = null;

// Procesar búsqueda
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['buscar_id'])) {
    $id = $_POST['buscar_id'];
    $exe = $pedido->obtenerPorId($conn, $id);
    
    if($exe->num_rows > 0) {
        $resultado_busqueda = mysqli_fetch_assoc($exe);
        $busqueda = true;
    }
}

// Limpiar búsqueda
if(isset($_GET['limpiar'])) {
    $busqueda = false;
    $resultado_busqueda = null;
}

// Insertar
if($accion == 'insertar' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $cedula = $_POST['cedula'];
    $id_pro = $_POST['id_pro'];
    $cantidad = $_POST['cantidad'];
    
    // Obtener stock actual del producto
    $res_stock = $producto->obtenerPorId($conn, $id_pro);
    $prod = mysqli_fetch_assoc($res_stock);
    $stock_actual = $prod['stock'];
    
    // Validar que haya stock suficiente
    if($stock_actual < $cantidad) {
        $error = "No hay suficiente stock. Stock disponible: " . $stock_actual;
    } else {
        // Insertar el pedido
        if($pedido->insertar($conn, $id, $cedula, $id_pro, $cantidad)) {
            // Restar del stock
            $nuevo_stock = $stock_actual - $cantidad;
            $producto->actualizarStock($conn, $id_pro, $nuevo_stock);
            
            // Mensaje si quedó en 0
            if($nuevo_stock == 0) {
                $mensaje = "Pedido creado. Advertencia: El producto está agotado.";
            } else {
                header("Location: pedido.php");
                exit();
            }
        }
    }
}

// Actualizar
if($accion == 'actualizar' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $cedula = $_POST['cedula'];
    $id_pro = $_POST['id_pro'];
    $cantidad = $_POST['cantidad'];
    
    // Obtener el pedido anterior
    $res_pedido_anterior = $pedido->obtenerPorId($conn, $id);
    $pedido_anterior = mysqli_fetch_assoc($res_pedido_anterior);
    $cantidad_anterior = $pedido_anterior['cantidad'];
    $id_pro_anterior = $pedido_anterior['id_pro'];
    
    // Obtener stock actual del producto
    $res_stock = $producto->obtenerPorId($conn, $id_pro);
    $prod = mysqli_fetch_assoc($res_stock);
    $stock_actual = $prod['stock'];
    
    // Si cambió el producto o la cantidad, ajustar stock
    if($id_pro_anterior != $id_pro) {
        // Devolver el stock del producto anterior
        $res_stock_anterior = $producto->obtenerPorId($conn, $id_pro_anterior);
        $prod_anterior = mysqli_fetch_assoc($res_stock_anterior);
        $nuevo_stock_anterior = $prod_anterior['stock'] + $cantidad_anterior;
        $producto->actualizarStock($conn, $id_pro_anterior, $nuevo_stock_anterior);
        
        // Restar del nuevo producto
        $nuevo_stock = $stock_actual - $cantidad;
        $producto->actualizarStock($conn, $id_pro, $nuevo_stock);
    } else {
        // Mismo producto, solo cambió cantidad
        $diferencia = $cantidad_anterior - $cantidad;
        $nuevo_stock = $stock_actual + $diferencia;
        $producto->actualizarStock($conn, $id_pro, $nuevo_stock);
    }
    
    if($pedido->actualizar($conn, $id, $cedula, $id_pro, $cantidad)) {
        header("Location: pedido.php");
        exit();
    }
}

// Eliminar
if($accion == 'eliminar') {
    $id = $_GET['id'];
    
    // Obtener el pedido antes de eliminarlo
    $res_pedido = $pedido->obtenerPorId($conn, $id);
    $ped = mysqli_fetch_assoc($res_pedido);
    $cantidad_pedido = $ped['cantidad'];
    $id_pro_pedido = $ped['id_pro'];
    
    // Devolver el stock al producto
    $res_stock = $producto->obtenerPorId($conn, $id_pro_pedido);
    $prod = mysqli_fetch_assoc($res_stock);
    $nuevo_stock = $prod['stock'] + $cantidad_pedido;
    $producto->actualizarStock($conn, $id_pro_pedido, $nuevo_stock);
    
    // Eliminar el pedido
    $pedido->eliminar($conn, $id);
    header("Location: pedido.php");
    exit();
}

// Obtener todos los pedidos
$res = $pedido->obtenerTodos($conn);
$pedidos = array();
if($res->num_rows > 0) {
    while($row = $res->fetch_assoc()) {
        $pedidos[] = $row;
    }
}

// Obtener todos los clientes
$res_clientes = $cliente->obtenerTodos($conn);
$clientes = array();
if($res_clientes->num_rows > 0) {
    while($row = $res_clientes->fetch_assoc()) {
        $clientes[] = $row;
    }
}

// Obtener todos los productos
$res_productos = $producto->obtenerTodos($conn);
$productos = array();
if($res_productos->num_rows > 0) {
    while($row = $res_productos->fetch_assoc()) {
        $productos[] = $row;
    }
}

include "../views/pedido.php";
?>
