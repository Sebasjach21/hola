<!DOCTYPE html>
<html>
<head>
    <title>Sistema de Productos y Clientes</title>
</head>
<body>
    <h1>Sistema de Gestión</h1>
    
    <a href="controllers/cliente.php"><button>Gestión de Clientes</button></a>
    <a href="controllers/producto.php"><button>Gestión de Productos</button></a>
    <a href="controllers/pedido.php"><button>Gestión de Pedidos</button></a>
</body>
</html>
