<?php
include "conexion.php";

class Cliente {
    public function obtenerTodos($conn) {
        $sql = "SELECT * FROM clientes";
        return mysqli_query($conn, $sql);
    }
    
    public function obtenerPorCedula($conn, $cedula) {
        $sql = "SELECT * FROM clientes WHERE cedula = '$cedula'";
        return mysqli_query($conn, $sql);
    }
    
    public function insertar($conn, $cedula, $nombre, $apellido) {
        $sql = "INSERT INTO clientes (cedula, nombre, apellido) VALUES ('$cedula', '$nombre', '$apellido')";
        return mysqli_query($conn, $sql);
    }
    
    public function actualizar($conn, $cedula, $nombre, $apellido) {
        $sql = "UPDATE clientes SET nombre='$nombre', apellido='$apellido' WHERE cedula='$cedula'";
        return mysqli_query($conn, $sql);
    }
    
    public function eliminar($conn, $cedula) {
        $sql = "DELETE FROM clientes WHERE cedula='$cedula'";
        return mysqli_query($conn, $sql);
    }
}
?>
