<?php
include "conexion.php";

class Pedidos {
    public function obtenerTodos($conn) {
        $sql = "SELECT * FROM pedido";
        return mysqli_query($conn, $sql);
    }
    
    public function obtenerPorId($conn, $id) {
        $sql = "SELECT * FROM pedido WHERE id_ped = '$id'";
        return mysqli_query($conn, $sql);
    }
    
    public function insertar($conn, $id, $cedula, $id_pro, $cantidad) {
        $sql = "INSERT INTO pedido (id_ped, cedula, id_pro, cantidad) VALUES ('$id', '$cedula', '$id_pro', '$cantidad')";
        return mysqli_query($conn, $sql);
    }
    
    public function actualizar($conn, $id, $cedula, $id_pro, $cantidad) {
        $sql = "UPDATE pedido SET cedula='$cedula', id_pro='$id_pro', cantidad='$cantidad' WHERE id_ped='$id'";
        return mysqli_query($conn, $sql);
    }
    
    public function eliminar($conn, $id) {
        $sql = "DELETE FROM pedido WHERE id_ped='$id'";
        return mysqli_query($conn, $sql);
    }
}
?>