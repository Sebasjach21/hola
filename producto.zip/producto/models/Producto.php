<?php
include "conexion.php";

class Producto {
    public function obtenerTodos($conn) {
        $sql = "SELECT * FROM productos";
        return mysqli_query($conn, $sql);
    }
    
    public function obtenerPorId($conn, $id) {
        $sql = "SELECT * FROM productos WHERE id_pro = '$id'";
        return mysqli_query($conn, $sql);
    }
    
    public function insertar($conn, $id , $nombre, $stock) {
        $sql = "INSERT INTO productos (id_pro, nombre, stock) VALUES ('$id', '$nombre', '$stock')";
        return mysqli_query($conn, $sql);
    }
    
    public function actualizar($conn, $id, $nombre, $stock) {
        $sql = "UPDATE productos SET nombre='$nombre', stock='$stock' WHERE id_pro='$id'";
        return mysqli_query($conn, $sql);
    }
    
    public function eliminar($conn, $id) {
        $sql = "DELETE FROM productos WHERE id_pro='$id'";
        return mysqli_query($conn, $sql);
    }
    
    public function restarStock($conn, $id, $cantidad) {
        $sql = "UPDATE productos SET stock = stock - $cantidad WHERE id_pro='$id'";
        return mysqli_query($conn, $sql);
    }
    
    public function actualizarStock($conn, $id, $nuevo_stock) {
        $sql = "UPDATE productos SET stock='$nuevo_stock' WHERE id_pro='$id'";
        return mysqli_query($conn, $sql);
    }
}
?>
