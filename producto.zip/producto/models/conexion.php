<?php
$server="localhost";
$user="root";
$pass="";
$dbname="jacho";

$conn=mysqli_connect($server,$user,$pass,$dbname);

if(!$conn)
{
    die("Conexion fallida:(".mysqli_errno().")".mysqli_error());
}
?>
