<!DOCTYPE html>
<html>
<head>
    <title>Gestión de Productos</title>
</head>
<body>
    <h1>Gestión de Productos</h1>
    
    <h2>Insertar Producto</h2>
    <form action="?accion=insertar" method="post">
        <input type="text" name="id" placeholder="ID del Producto" required><br>
        <input type="text" name="nombre" placeholder="Nombre del Producto" required><br>
        <input type="number" name="stock" placeholder="Stock" required><br>
        <button type="submit">Insertar</button>
    </form>
    
    <h2>Editar Producto</h2>
    <form action="?accion=actualizar" method="post">
        <input type="text" id="id_edit" name="id" placeholder="ID" readonly required><br>
        <input type="text" id="nom_edit" name="nombre" placeholder="Nombre del Producto" required><br>
        <input type="number" id="stock_edit" name="stock" placeholder="Stock" required><br>
        <button type="submit">Actualizar</button>
    </form>
    
    <h2>Buscar Producto</h2>
    <form method="post">
        <input type="text" name="buscar_id" placeholder="ID a buscar" required>
        <button type="submit">Buscar</button>
        <?php if($busqueda) { echo "<a href='?limpiar=1'><button type='button'>Limpiar</button></a>"; } ?>
    </form>
    
    <h2>Lista de Productos</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Stock</th>
            <th>Acciones</th>
        </tr>
        <?php
        if($busqueda && $resultado_busqueda) {
            $p = $resultado_busqueda;
            echo "<tr>";
            echo "<td>".($p['id_pro'] ?? '')."</td>";
            echo "<td>".$p['nombre']."</td>";
            echo "<td>".$p['stock']."</td>";
            echo "<td>";
            $id_val = $p['id_pro'] ?? '';
            echo "<button onclick=\"document.getElementById('id_edit').value='".$id_val."'; document.getElementById('nom_edit').value='".$p['nombre']."'; document.getElementById('stock_edit').value='".$p['stock']."';\">Editar</button> ";
            echo "<a href='?accion=eliminar&id=".$id_val."' onclick=\"return confirm('¿Seguro?')\"><button type='button'>Eliminar</button></a>";
            echo "</td>";
            echo "</tr>";
        } else if(!$busqueda && count($productos) > 0) {
            foreach($productos as $p) {
                echo "<tr>";
                echo "<td>".($p['id_pro'] ?? '')."</td>";
                echo "<td>".$p['nombre']."</td>";
                echo "<td>".$p['stock']."</td>";
                echo "<td>";
                $id_val = $p['id_pro'] ?? '';
                echo "<button onclick=\"document.getElementById('id_edit').value='".$id_val."'; document.getElementById('nom_edit').value='".$p['nombre']."'; document.getElementById('stock_edit').value='".$p['stock']."';\">Editar</button> ";
                echo "<a href='?accion=eliminar&id=".$id_val."' onclick=\"return confirm('¿Seguro?')\"><button type='button'>Eliminar</button></a>";
                echo "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No hay productos</td></tr>";
        }
        ?>
    </table>
    
    <br>
    <a href="../index.php"><button>Volver</button></a>
    <a href="../controllers/cliente.php"><button>Ver Clientes</button></a>
</body>
</html>
