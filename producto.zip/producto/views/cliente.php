<!DOCTYPE html>
<html>
<head>
    <title>Gestión de Clientes</title>
</head>
<body>
    <h1>Gestión de Clientes</h1>
    
    <h2>Insertar Cliente</h2>
    <form action="?accion=insertar" method="post">
        <input type="text" name="cedula" placeholder="Cédula" required><br>
        <input type="text" name="nombre" placeholder="Nombre" required><br>
        <input type="text" name="apellido" placeholder="Apellido" required><br>
        <button type="submit">Insertar</button>
    </form>
    
    <h2>Editar Cliente</h2>
    <form action="?accion=actualizar" method="post">
        <input type="text" id="ced" name="cedula" placeholder="Cédula" required><br>
        <input type="text" id="nom" name="nombre" placeholder="Nombre" required><br>
        <input type="text" id="ape" name="apellido" placeholder="Apellido" required><br>
        <button type="submit">Actualizar</button>
    </form>
    
    <h2>Buscar Cliente</h2>
    <form method="post">
        <input type="text" name="buscar_cedula" placeholder="Cédula a buscar" required>
        <button type="submit">Buscar</button>
        <?php if($busqueda) { echo "<a href='?limpiar=1'><button type='button'>Limpiar</button></a>"; } ?>
    </form>
    
    <h2>Lista de Clientes</h2>
    <table border="1">
        <tr>
            <th>Cédula</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Acciones</th>
        </tr>
        <?php
        if($busqueda && $resultado_busqueda) {
            $c = $resultado_busqueda;
            echo "<tr>";
            echo "<td>".$c['cedula']."</td>";
            echo "<td>".$c['nombre']."</td>";
            echo "<td>".$c['apellido']."</td>";
            echo "<td>";
            echo "<button onclick=\"document.getElementById('ced').value='".$c['cedula']."'; document.getElementById('nom').value='".$c['nombre']."'; document.getElementById('ape').value='".$c['apellido']."';\">Editar</button> ";
            echo "<a href='?accion=eliminar&cedula=".$c['cedula']."' onclick=\"return confirm('¿Seguro?')\"><button type='button'>Eliminar</button></a>";
            echo "</td>";
            echo "</tr>";
        } else if(!$busqueda && count($clientes) > 0) {
            foreach($clientes as $c) {
                echo "<tr>";
                echo "<td>".$c['cedula']."</td>";
                echo "<td>".$c['nombre']."</td>";
                echo "<td>".$c['apellido']."</td>";
                echo "<td>";
                echo "<button onclick=\"document.getElementById('ced').value='".$c['cedula']."';
                 document.getElementById('nom').value='".$c['nombre']."';
                  document.getElementById('ape').value='".$c['apellido']."';
                  \">Editar</button> ";
                echo "<a href='?accion=eliminar&cedula=".$c['cedula']."' onclick=\"return confirm('¿Seguro?')\"><button type='button'>Eliminar</button></a>";
                echo "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No hay clientes</td></tr>";
        }
        ?>
    </table>
    
    <br>
    <a href="../index.php"><button>Volver</button></a>
    <a href="../controllers/producto.php"><button>Ver Productos</button></a>
</body>
</html>
