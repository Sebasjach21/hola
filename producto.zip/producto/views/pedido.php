<!DOCTYPE html>
<html>
<head>
    <title>Gestión de Pedidos</title>
    <script>
        function editarPedido(id, cedula, id_pro, cantidad) {
            document.getElementById('id_edit').value = id;
            document.getElementById('cliente_edit').value = cedula;
            document.getElementById('producto_edit').value = id_pro;
            document.getElementById('cantidad_edit').value = cantidad;
        }
    </script>
</head>
<body>
    <h1>Gestión de Pedidos</h1>
    
    <?php
    if(isset($error)) {
        echo "Error: " . $error . "<br>";
    }
    if(isset($mensaje)) {
        echo "Advertencia: " . $mensaje . "<br>";
    }
    ?>
    
    <h2>Insertar Pedido</h2>
    <form action="?accion=insertar" method="post">
        <input type="text" name="id" placeholder="ID del Pedido" required><br>
        <label for="cliente_insert">Cliente:</label>
        <select name="cedula" id="cliente_insert" required>
            <option value="">Selecciona un cliente</option>
            <?php
            if(count($clientes) > 0) {
                foreach($clientes as $c) {
                    echo "<option value='".$c['cedula']."'>".$c['nombre']." ".$c['apellido']."</option>";
                }
            }
            ?>
        </select><br>
        <label for="producto_insert">Producto:</label>
        <select name="id_pro" id="producto_insert" required>
            <option value="">Selecciona un producto</option>
            <?php
            if(count($productos) > 0) {
                foreach($productos as $prod) {
                    $estado = $prod['stock'] > 0 ? '' : ' (Sin stock)';
                    $disabled = $prod['stock'] > 0 ? '' : ' disabled';
                    echo "<option value='".$prod['id_pro']."'".$disabled.">".$prod['nombre']." - Stock: ".$prod['stock'].$estado."</option>";
                }
            }
            ?>
        </select><br>
        <input type="number" name="cantidad" placeholder="Cantidad" required><br>
        <button type="submit">Insertar</button>
    </form>
    
    <h2>Editar Pedido</h2>
    <form action="?accion=actualizar" method="post">
        <input type="text" id="id_edit" name="id" placeholder="ID" readonly required><br>
        <label for="cliente_edit">Cliente:</label>
        <select name="cedula" id="cliente_edit" required>
            <option value="">Selecciona un cliente</option>
            <?php
            if(count($clientes) > 0) {
                foreach($clientes as $c) {
                    echo "<option value='".$c['cedula']."'>".$c['nombre']." ".$c['apellido']."</option>";
                }
            }
            ?>
        </select><br>
        <label for="producto_edit">Producto:</label>
        <select name="id_pro" id="producto_edit" required>
            <option value="">Selecciona un producto</option>
            <?php
            if(count($productos) > 0) {
                foreach($productos as $prod) {
                    $estado = $prod['stock'] > 0 ? '' : ' (Sin stock)';
                    $disabled = $prod['stock'] > 0 ? '' : ' disabled';
                    echo "<option value='".$prod['id_pro']."'".$disabled.">".$prod['nombre']." - Stock: ".$prod['stock'].$estado."</option>";
                }
            }
            ?>
        </select><br>
        <input type="number" id="cantidad_edit" name="cantidad" placeholder="Cantidad" required><br>
        <button type="submit">Actualizar</button>
    </form>
    
    <h2>Buscar Pedido</h2>
    <form method="post">
        <input type="text" name="buscar_id" placeholder="ID a buscar" required>
        <button type="submit">Buscar</button>
        <?php if($busqueda) { echo "<a href='?limpiar=1'><button type='button'>Limpiar</button></a>"; } ?>
    </form>
    
    <h2>Lista de Pedidos</h2>
    <table border="1">
        <tr>
            <th>ID Pedido</th>
            <th>Cliente</th>
            <th>Producto</th>
            <th>Cantidad</th>
            <th>Acciones</th>
        </tr>
        <?php
        if($busqueda && $resultado_busqueda) {
            $p = $resultado_busqueda;
            $cliente_nombre = '';
            $producto_nombre = '';
            
            // Buscar nombre del cliente
            foreach($clientes as $c) {
                if($c['cedula'] == $p['cedula']) {
                    $cliente_nombre = $c['nombre'] . ' ' . $c['apellido'];
                    break;
                }
            }
            
            // Buscar nombre del producto
            foreach($productos as $prod) {
                if($prod['id_pro'] == $p['id_pro']) {
                    $producto_nombre = $prod['nombre'];
                    break;
                }
            }
            
            echo "<tr>";
            echo "<td>".$p['id_ped']."</td>";
            echo "<td>".$cliente_nombre."</td>";
            echo "<td>".$producto_nombre."</td>";
            echo "<td>".$p['cantidad']."</td>";
            echo "<td>";
            echo "<button onclick=\"editarPedido('".$p['id_ped']."', '".$p['cedula']."', '".$p['id_pro']."', '".$p['cantidad']."')\">Editar</button> ";
            echo "<a href='?accion=eliminar&id=".$p['id_ped']."' onclick=\"return confirm('¿Seguro?')\"><button type='button'>Eliminar</button></a>";
            echo "</td>";
            echo "</tr>";
        } else if(!$busqueda && count($pedidos) > 0) {
            foreach($pedidos as $p) {
                $cliente_nombre = '';
                $producto_nombre = '';
                
                // Buscar nombre del cliente
                foreach($clientes as $c) {
                    if($c['cedula'] == $p['cedula']) {
                        $cliente_nombre = $c['nombre'] . ' ' . $c['apellido'];
                        break;
                    }
                }
                
                // Buscar nombre del producto
                foreach($productos as $prod) {
                    if($prod['id_pro'] == $p['id_pro']) {
                        $producto_nombre = $prod['nombre'];
                        break;
                    }
                }
                
                echo "<tr>";
                echo "<td>".$p['id_ped']."</td>";
                echo "<td>".$cliente_nombre."</td>";
                echo "<td>".$producto_nombre."</td>";
                echo "<td>".$p['cantidad']."</td>";
                echo "<td>";
                echo "<button onclick=\"editarPedido('".$p['id_ped']."', '".$p['cedula']."', '".$p['id_pro']."', '".$p['cantidad']."')\">Editar</button> ";
                echo "<a href='?accion=eliminar&id=".$p['id_ped']."' onclick=\"return confirm('¿Seguro?')\"><button type='button'>Eliminar</button></a>";
                echo "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>No hay pedidos</td></tr>";
        }
        ?>
    </table>
    
    <br>
    <a href="../index.php"><button>Volver</button></a>
    <a href="../controllers/producto.php"><button>Ver Productos</button></a>
    <a href="../controllers/cliente.php"><button>Ver Clientes</button></a>
</body>
</html>
