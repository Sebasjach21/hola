<?php
session_start();
include("conexion.php");

$u=$_POST['usuario'] ?? '';
$p=$_POST['contra'] ?? '';

$conn=Conectar();
$query= $conn->prepare("SELECT * FROM usuarios WHERE usuario=?");

$query->bind_param("s",$u);
$query->execute();
$res=$query->get_result()->fetch_assoc();
$query->close();
$conn->close();



if($res && (password_verify($p, $res['contra']) || $res['contra'] === $p)){
    $_SESSION['usuario']=$u;
    $_SESSION['success']="Inicio de sesión exitoso.";
    header("Location: clientes.php");
    exit();
} else {
    $_SESSION['error'] = 'Usuario o contraseña incorrectos';
    header("Location: index.php");
    exit();
}
?>
