<?php
function Conectar()
{
    $s="localhost";
    $u="root";
    $p="";
    $b="banco";

    $conexion=mysqli_connect($s,$u,$p,$b);
    if(!$conexion){
        die("Error de conexion: ".mysqli_connect_error());
    }
    return $conexion;
}
?>