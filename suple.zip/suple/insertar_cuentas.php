<?php
include("conexion.php");
$conn=Conectar();

$cuenta=$_POST['tipo'];
$cliente=$_POST['cliente'];

// Obtener la cédula del cliente por su nombre
$verificar="SELECT cedula FROM clientes WHERE nombre='$cliente'";
$check=mysqli_query($conn,$verificar);

if(mysqli_num_rows($check) > 0){
    $row=mysqli_fetch_assoc($check);
    $cedula=$row['cedula'];
    
    $sql="insert into cuenta (tipo_cuenta,cedula) values ('$cuenta','$cedula')";
    $result=mysqli_query($conn,$sql);
    if($result){
        echo "cuenta registrada";
        header("Location: clientes.php");
    }else{
        echo "error al registrar cuenta";
    }
} else {
    echo "Error: El cliente no existe";
}
$conn->close();
?>