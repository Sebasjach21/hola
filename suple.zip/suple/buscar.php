<?php
include("conexion.php");
$conn=Conectar();

$cedula=$_GET['cedula'];

$sql="select nombre from clientes where cedula='$cedula'";
$result=mysqli_query($conn,$sql);
$cliente=mysqli_fetch_assoc($result);

$sql1="select ncueta, saldo from cuenta where cedula='$cedula'";
$result1=mysqli_query($conn,$sql1);
$row=mysqli_fetch_assoc($result1);
$cuenta=$row['ncueta'];
$saldo=$row['saldo'];

$sql2="select * from transaccion where id_cuenta='$cuenta'";
$result2=mysqli_query($conn,$sql2);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Búsqueda de Transacciones</title>
    
</head>
<body>
    <div class="container">
        <h2>Transacciones de <?php echo htmlspecialchars($cliente['nombre']); ?></h2>
        <p><strong>Cédula:</strong> <?php echo htmlspecialchars($cedula); ?></p>
        <p><strong>Cuenta:</strong> <?php echo htmlspecialchars($cuenta); ?></p>
        <p><strong>Saldo Actual:</strong> $<?php echo number_format($saldo, 2); ?></p>

        <?php if(mysqli_num_rows($result2) > 0) { ?>
        <table border="1">
            <thead>
                <tr>
                    <th>Tipo</th>
                    <th>Monto</th>
                    <th>Fecha</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($result2)) { ?>
                <tr>
                    <td><?php echo $row['tipo_tran']; ?></td>
                    <td>$<?php echo number_format($row['monto'], 2); ?></td>
                    <td><?php echo $row['fecha']; ?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
        <?php } else { ?>
        <p class="error">No hay transacciones para esta cuenta.</p>
        <?php } ?>
    </div>
    <button ><a href="clientes.php">volver</a></button>
</body>
</html>