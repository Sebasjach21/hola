<?php
session_start();

// Validar que hay sesión activa
if(!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit;
}

include("conexion.php");
$conn=Conectar();

$sql="select nombre from clientes";
$result=mysqli_query($conn,$sql);

$sql2="select ncueta from cuenta";
$result2=mysqli_query($conn,$sql2);
?>



<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clientes</title>
</head>
<body>
    <div class="header">
        <h2>Panel de Control - <?php echo htmlspecialchars($_SESSION['usuario']); ?></h2>
        <a href="logout.php" class="logout-btn">Cerrar Sesión</a>
    </div>
    
    <div class="container">
    <h2>registro de clientes</h2>
    <form action="insertar_clientes.php" method="POST">
        <label for="cedula">cedula:</label><input type="text" name="cedula" id="cedula" required><br>
        <label for="nombre">nombre:</label><input type="text" name="nombre" id="nombre" required><br>
        <input type="submit" value="Registrar Cliente">
    </form>
    <h2>registro de cuentas </h2>
    <form action="insertar_cuentas.php" method="POST">
        <label for="tipo">tipo de cuenta:</label><select name="tipo" id="tipo">
            <option value="ahorro">ahorro</option>
            <option value="corriente">corriente</option>
        </select><br>
        <label for="cliente">cliente:</label>
        <select name="cliente" id="cliente">
            <?php
            while($row=mysqli_fetch_assoc($result)){
                echo "<option value='".$row['nombre']."'>".$row['nombre']."</option>";
            }
            ?>
        </select><br>
        <input type="submit" value="Registrar cuenta">
    </form>
    <h2>registro de transaccion</h2>
    <form action="trans.php" method="POST">
        <label for="tipoTran">Tipo de transaccion:</label><select name="tipoTran" id="tipoTran">
            <option value="deposito">deposito</option>
            <option value="retiro">retiro</option>
        </select> <br>
        <label for="monto">Monto:</label><input type="number" name="monto" id="monto" required><br>
        <label for="fecha">Fecha:</label><input type="date" name="fecha" id="fecha" required><br>
        <label for="cuenta">Cuenta:</label>
        <select name="cuenta" id="cuenta">
            <?php
            while($row=mysqli_fetch_assoc($result2)){
                echo "<option value='".$row['ncueta']."'>".$row['ncueta']."</option>";
            }
            ?>
            <br>
            <input type="submit" value="Registrar transaccion">
        </select><br>
    </form>
    <h2>buscar cliente</h2>
    <form action="buscar.php" method="GET">
        <label for="buscar">Ingrese la cedula del cliente</label>
        <input type="text" name="cedula" id="cedula" required>
        <input type="submit" value="Buscar">
    </form>
    </div>
</body>
</html>