<?php
include("conexion.php");
$conn=Conectar();

$cedula=$_POST['cedula'];
$nombre=$_POST['nombre'];

$sql="insert into clientes (cedula,nombre) values ('$cedula','$nombre')";
$result=mysqli_query($conn,$sql);
if($result){
    echo "cliente registrado";
    header("Location: clientes.php");   
}else{
    echo "error al registrar cliente";
}

?>