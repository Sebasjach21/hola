<?php
include("conexion.php");
$conn=Conectar();

$tipo=$_POST['tipoTran'];
$monto=$_POST['monto'];
$fecha=$_POST['fecha'];
$ncueta=$_POST['cuenta'];


if($monto <= 0) {
    echo "Error: El monto debe ser mayor a 0";
    exit;
}

if($tipo == 'retiro') {
    
    $validar = "SELECT saldo FROM cuenta WHERE ncueta = '$ncueta'";
    $result = mysqli_query($conn, $validar);
    $row = mysqli_fetch_assoc($result);
    
    if(!$row) {
        echo "Error: Cuenta no encontrada";
        exit;
    }
    
    if($row['saldo'] < $monto) {
        echo "Saldo insuficiente. Saldo disponible: " . $row['saldo'];
        exit;
    }
    
    
    $actualizar = "UPDATE cuenta SET saldo = saldo - $monto WHERE ncueta = '$ncueta'";
    mysqli_query($conn, $actualizar);
    
} else if($tipo == 'deposito') {
  
    $actualizar = "UPDATE cuenta SET saldo = saldo + $monto WHERE ncueta = '$ncueta'";
    mysqli_query($conn, $actualizar);
}


$sql = "INSERT INTO transaccion (tipo_tran, monto, fecha, id_cuenta) VALUES ('$tipo', '$monto', '$fecha', '$ncueta')";
$result = mysqli_query($conn, $sql);

if($result) {
    echo "Transacción registrada exitosamente";
    header("Location: clientes.php");
} else {
    echo "Error al registrar transacción";
}

$conn->close();
?>